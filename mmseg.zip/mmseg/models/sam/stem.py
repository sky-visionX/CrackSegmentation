import torch.nn as nn
import torch
# from DCNv33.modules.dcnv3 import DCNv3

class Stem(nn.Module):
    def __init__(self, inplanes):
        super(Stem, self).__init__()
        self.conv1 = nn.Conv2d(3, inplanes, kernel_size=7, stride=2, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(inplanes)
        self.relu1 = nn.ReLU(inplace=True)
        self.conv2 = nn.Conv2d(inplanes, inplanes, kernel_size=3, stride=2, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(inplanes)
        self.relu2 = nn.ReLU(inplace=True)
        self.conv3 = nn.Conv2d(inplanes, inplanes, kernel_size=3, stride=2, padding=1, bias=False)
        self.bn3 = nn.BatchNorm2d(inplanes)
        self.relu3 = nn.ReLU(inplace=True)
        self.maxpool = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)

        # self.deformable_conv2d = DCNv3(channels=inplanes, kernel_size=1).cuda()  # 加入可变形卷积

    def forward(self, x):
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.relu1(x)

        # # 可变形卷积
        # x = x.permute(0, 2, 3, 1)  # 可变形卷积输入维度
        # x = self.deformable_conv2d(x)
        # x = x.permute(0, 3, 1, 2)  # 可变形卷积输入维度

        x = self.conv2(x)
        x = self.bn2(x)
        x = self.relu2(x)
        x = self.conv3(x)
        x = self.bn3(x)
        x = self.relu3(x)
        x = self.maxpool(x)
        return x

# # Usage
# inplanes = 64  # You can set this to the desired number of inplanes
# input = torch.randn(2, 3, 1024, 1024).cuda()
# stem = Stem(inplanes).cuda()
# print((stem(input)).shape)