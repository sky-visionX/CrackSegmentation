
import torch

word_embedding = torch.load(r'/models/mmseg/models/sam/clip/txt_encoding.pth')
print(word_embedding.shape)