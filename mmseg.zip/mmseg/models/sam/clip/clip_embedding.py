import os
import clip
import torch
from torch import nn


## PAOT
# ORGAN_NAME = ['Spleen', 'Right Kidney', 'Left Kidney', 'Gall Bladder', 'Esophagus']

ORGAN_NAME = ['crack']

# Load the model
device = "cuda" if torch.cuda.is_available() else "cpu"
model, preprocess = clip.load('ViT-B/32', device)


# text_inputs = torch.cat([clip.tokenize(f'A photo of a {item}') for item in ORGAN_NAME]).to(device)

text_inputs = clip.tokenize('crack').to(device)


# print(text_inputs)
# Calculate text embedding features
with torch.no_grad():
    text_features = model.encode_text(text_inputs)
    print(text_features.shape, text_features.dtype)
    # 一定得价格
    # print(text_features)
    torch.save(text_features, 'txt_encoding.pth')

    text_features = text_features.float()

    text_to_vision = nn.Linear(512, 256).cuda()
    print(text_to_vision(text_features).shape)


